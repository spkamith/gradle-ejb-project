package gradle.java.sample;

import org.junit.Test;

import gradle.java.bo.RecordingProduct;

import static org.junit.Assert.*;
public class UnitPriceCalculatorTest {
	
	@Test
	public void testCalculateUnitPrice() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
		
		RecordingProduct recordingProduct = getRecordingProduct();
		
		recordingProduct = unitPriceCalculator.calculateUnitPrice(recordingProduct);
		
		assertEquals(recordingProduct.getUnitPriceWithPromo(), Double.valueOf(1.0));
		assertEquals(recordingProduct.getUnitPriceWithoutPromo(), Double.valueOf(1.0));
		
	}
	
	@Test
	public void testTestFreeTypeUnitPrice() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
		
		RecordingProduct recordingProduct = getRecordingProduct();
		//Free Part Qty
		recordingProduct.setRecodingTypCd(2L);
		recordingProduct.setFreeProductType(1L);
		
		recordingProduct.setRecordPrice(7.56);
		recordingProduct.setDefContent(5.0);
		recordingProduct.setRecordQty(5.0);
		recordingProduct.setRecordPrdContent(5.0);
		recordingProduct.setFreePrdQty(1.0);
		
		recordingProduct = unitPriceCalculator.calculateUnitPrice(recordingProduct);
		
		assertEquals(recordingProduct.getUnitPriceWithPromo(), Double.valueOf(1.512) );
		assertEquals(recordingProduct.getUnitPriceWithoutPromo(), Double.valueOf(1.89));
		
		recordingProduct.setFreeProductType(1L);
		recordingProduct.setRecordPrice(0.22);
		recordingProduct.setDefContent(0.1);
		recordingProduct.setRecordQty(1.0);
		recordingProduct.setRecordPrdContent(0.1);
		recordingProduct.setFreePrdQty(null);
		recordingProduct.setFreePrdContent(0.025);
		
		recordingProduct = unitPriceCalculator.calculateUnitPrice(recordingProduct);
		assertEquals(recordingProduct.getUnitPriceWithPromo(), Double.valueOf(0.22) );
		assertEquals(recordingProduct.getUnitPriceWithoutPromo(), Double.valueOf(0.2933));
		
		recordingProduct.setFreeProductType(1L);
		recordingProduct.setRecordPrice(5.46);
		recordingProduct.setDefContent(5.0);
		recordingProduct.setRecordQty(5.0);
		recordingProduct.setRecordPrdContent(5.0);
		recordingProduct.setFreePrdQty(null);
		recordingProduct.setFreePrdContent(null);
		recordingProduct.setFreePrdContentPercent(20.0);
		
		recordingProduct = unitPriceCalculator.calculateUnitPrice(recordingProduct);
		assertEquals(recordingProduct.getUnitPriceWithPromo(), Double.valueOf(1.092) );
		assertEquals(recordingProduct.getUnitPriceWithoutPromo(), Double.valueOf(1.365));
	}
	

	@Test
	public void testStandardPrice() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
	    
		Double recordPrice = 2.0;
		Double defContent = 0.5;
		Double recordQty  = 1.0;
		Double recordPrdContent = 1.0;
		
		Double standardPrice = unitPriceCalculator.standardPrice(recordPrice, defContent, recordQty, recordPrdContent);	
		
		assertEquals(standardPrice, Double.valueOf(1.0));
	}
	
	@Test
	public void testPriceByFreePartQty() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
	    
		Double recordPrice = 7.56;
		Double defContent = 5.0;
		Double recordQty  = 5.0;
		Double recordPrdContent = 5.0;
		Double freePrdQty = 1.0;
		Double unitPriceExcludingPromo = unitPriceCalculator.priceByFreePartQtyExcludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdQty);
		Double unitPriceIncludingPromo = unitPriceCalculator.priceByFreePartQtyIncludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdQty);
		
		assertEquals(unitPriceExcludingPromo, Double.valueOf(1.89));
		
		unitPriceIncludingPromo = UnitPriceCalculator.round(unitPriceIncludingPromo, 4);
		assertEquals(unitPriceIncludingPromo, Double.valueOf(1.512));
	}
	
	@Test
	public void testPriceByFreeExtraQty() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
	    
		Double recordPrice = 1.21;
		Double defContent = 5.0;
		Double recordQty  = 2.0;
		Double recordPrdContent = 5.0;
		Double freePrdQty = 2.0;
		Double unitPriceExcludingPromo = unitPriceCalculator.priceByFreeExtraQtyExcludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdQty);
		Double unitPriceIncludingPromo = unitPriceCalculator.priceByFreeExtraQtyIncludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdQty);
		
		assertEquals(unitPriceExcludingPromo, Double.valueOf(0.605));
		assertEquals(unitPriceIncludingPromo, Double.valueOf(0.3025));
	}
	
	@Test
	public void testPriceByFreePartCntAmnt() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
	    
		Double recordPrice = 0.22;
		Double defContent = 0.1;
		Double recordQty  = 1.0;
		Double recordPrdContent = 0.1;
		Double freePrdCnt = 0.025;
		Double unitPriceExcludingPromo = unitPriceCalculator.priceByFreePartCntAmtExcludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdCnt);
		Double unitPriceIncludingPromo = unitPriceCalculator.priceByFreePartCntAmtIncludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdCnt);
		
		unitPriceExcludingPromo = UnitPriceCalculator.round(unitPriceExcludingPromo, 4);
		assertEquals(unitPriceExcludingPromo, Double.valueOf(0.2933));
		assertEquals(unitPriceIncludingPromo, Double.valueOf(0.22));
	}
	
	@Test
	public void testPriceByFreeExtraCntAmnt() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
	    
		Double recordPrice = 0.75;
		Double defContent = 0.1;
		Double recordQty  = 1.0;
		Double recordPrdContent = 0.1;
		Double freePrdCnt = 0.01;
		Double unitPriceExcludingPromo = unitPriceCalculator.priceByFreeExtraCntAmtExcludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdCnt);
		Double unitPriceIncludingPromo = unitPriceCalculator.priceByFreeExtraCntAmtIncludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdCnt);
		
		unitPriceExcludingPromo = UnitPriceCalculator.round(unitPriceExcludingPromo, 2);
		
		assertEquals(unitPriceExcludingPromo, Double.valueOf(0.75));
		
		unitPriceIncludingPromo = UnitPriceCalculator.round(unitPriceIncludingPromo, 4);
		assertEquals(unitPriceIncludingPromo, Double.valueOf(0.6818));
	}
	
	@Test
	public void testPriceByFreePartCntPer() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
	    
		Double recordPrice = 5.46;
		Double defContent = 5.0;
		Double recordQty  = 5.0;
		Double recordPrdContent = 5.0;
		Double freePrdContentPercent = 20.0;
		Double unitPriceExcludingPromo = unitPriceCalculator.priceByFreePartCntPerExcludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdContentPercent);
		Double unitPriceIncludingPromo = unitPriceCalculator.priceByFreePartCntPerIncludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdContentPercent);
		
		unitPriceIncludingPromo = UnitPriceCalculator.round(unitPriceIncludingPromo, 4);
		assertEquals(unitPriceExcludingPromo, Double.valueOf(1.365));
		assertEquals(unitPriceIncludingPromo, Double.valueOf(1.092));
	}
	
	@Test
	public void testPriceByFreeExtraCntPer() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
	    
		Double recordPrice = 0.99;
		Double defContent = 1.0;
		Double recordQty  = 1.0;
		Double recordPrdContent = 1.0;
		Double freePrdContentPercent = 25.0;
		Double unitPriceExcludingPromo = unitPriceCalculator.priceByFreeExtraCntPerExcludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdContentPercent);
		Double unitPriceIncludingPromo = unitPriceCalculator.priceByFreeExtraCntPerIncludingPromo(recordPrice, defContent, recordQty, recordPrdContent, freePrdContentPercent);
		
		assertEquals(unitPriceExcludingPromo, Double.valueOf(0.99));
		assertEquals(unitPriceIncludingPromo, Double.valueOf(0.792));
	}
	
	@Test
	public void testPriceByBonusPieceAmnt() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
	    
		Double recordPrice = 1.40;
		Double defContent = 2.5;
		Double recordQty  = 6.0;
		Double recordPrdContent = 2.5;
		Double bonusRedAmount = 0.1;
		Double unitPriceExcludingPromo = unitPriceCalculator.priceByBonusPieceAmtIncludingExcludingPromo(recordPrice, defContent,  recordPrdContent, bonusRedAmount);
		
		unitPriceExcludingPromo = UnitPriceCalculator.round(unitPriceExcludingPromo, 2);
		assertEquals(unitPriceExcludingPromo, Double.valueOf(1.3));
	}
	
	@Test
	public void testPriceByBonusTotalAmnt() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
	    
		Double recordPrice = 8.40;
		Double defContent = 2.5;
		Double recordQty  = 6.0;
		Double recordPrdContent = 2.5;
		Double bonusRedAmount = 2.4;
		Double unitPriceExcludingPromo = unitPriceCalculator.priceByBonusTotalAmtIncludingExcludingPromo(recordPrice, defContent, recordQty, recordPrdContent, bonusRedAmount);
		
		assertEquals(unitPriceExcludingPromo, Double.valueOf(1.0));
	}
	
	@Test
	public void testPriceByBonusPiecePer() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
	    
		Double recordPrice = 1.23;
		Double defContent = 5.0;
		Double recordQty  = 5.0;
		Double recordPrdContent = 5.0;
		Double bonusRedAmountPer = 10.0;
		Double unitPriceExcludingPromo = unitPriceCalculator.priceByBonusPiecePerIncludingExcludingPromo(recordPrice, defContent, recordQty,  recordPrdContent, bonusRedAmountPer);
		
		assertEquals(unitPriceExcludingPromo, Double.valueOf(1.107));
	}
	
	@Test
	public void testPriceByBonusTotalPer() {
		UnitPriceCalculator unitPriceCalculator = new UnitPriceCalculator();
	    
		Double recordPrice = 6.15;
		Double defContent = 5.0;
		Double recordQty  = 5.0;
		Double recordPrdContent = 5.0;
		Double bonusRedAmountPer = 10.0;
		Double unitPriceExcludingPromo = unitPriceCalculator.priceByBonusTotalPerIncludingExcludingPromo(recordPrice, defContent, recordQty,  recordPrdContent, bonusRedAmountPer);
		assertEquals(unitPriceExcludingPromo, Double.valueOf(1.107));
	}
	

	private RecordingProduct getRecordingProduct() {
		RecordingProduct recordingProduct = new RecordingProduct();
		
		recordingProduct.setRecodingTypCd(1L);
		recordingProduct.setRecordPrice(2.0);
		recordingProduct.setDefContent(0.5);
		recordingProduct.setRecordQty(1.0);
		recordingProduct.setRecordPrdContent(1.0);
		
		
		return recordingProduct;
	}
}
