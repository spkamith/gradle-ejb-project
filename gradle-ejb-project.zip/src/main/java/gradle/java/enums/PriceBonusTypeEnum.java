package gradle.java.enums;

public enum PriceBonusTypeEnum {
	PIECE(1L),
	TOTAL(2L);
	
	private Long priceBonusType;

	private PriceBonusTypeEnum(Long recordSource) {
		this.priceBonusType = recordSource;
	}
	
	public Long getPriceBonusType() {
		return this.priceBonusType;
	}
	
	public static PriceBonusTypeEnum getValue(Long priceBonusType) {
		for(PriceBonusTypeEnum bonusTypeEnum : values())
		{
			if(bonusTypeEnum.getPriceBonusType() == priceBonusType) 
				return bonusTypeEnum;
		}
		return null;
	}
}
