package gradle.java.enums;

public enum RecordingTypeEnum {
	STANDARD(1L),
	FREE(2L),
	BONUS(3L),
	NOTFOUND(4L);
	
	private Long recodingType;

	private RecordingTypeEnum(Long recodingType) {
		this.recodingType = recodingType;
	}
	
	public Long getRecodingType() {
		return this.recodingType;
	}
	
	public static RecordingTypeEnum getValue(Long recodingType) {
		for(RecordingTypeEnum recordingType : values())
		{
			if(recordingType.getRecodingType() == recodingType) 
				return recordingType;
		}
		return null;
	}
} 