package gradle.java.enums;

public enum RecordSourceEnum {
	DOT(1L),
	CENTRAL(2L),
	ONLINE(3L),
	EXTERNAL(4L);
	
	private Long recordSource;

	private RecordSourceEnum(Long recordSource) {
		this.recordSource = recordSource;
	}
	
	public Long getRecordSource() {
		return this.recordSource;
	}
}
