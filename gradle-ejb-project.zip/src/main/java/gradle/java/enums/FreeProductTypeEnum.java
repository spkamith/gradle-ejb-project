package gradle.java.enums;

public enum FreeProductTypeEnum {
	PART(1L),
	EXTRA(2L);
	
	private Long freeProductType;

	private FreeProductTypeEnum(Long recordSource) {
		this.freeProductType = recordSource;
	}
	
	public Long getFreeProductType() {
		return this.freeProductType;
	}

	
	public static FreeProductTypeEnum getValue(Long freeProductType) {
		for(FreeProductTypeEnum freeTypeEnum : values())
		{
			if(freeTypeEnum.getFreeProductType() == freeProductType) 
				return freeTypeEnum;
		}
		return null;
	}
}
