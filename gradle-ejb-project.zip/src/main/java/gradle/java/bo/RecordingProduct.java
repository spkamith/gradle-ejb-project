package gradle.java.bo;

public class RecordingProduct {
	
	private Long priceRecordingId;
	private Long recProductId;
	private Long recodingTypCd;
	private Long recodeSourceCd;
	
	private Long priceBonusType;
	private Long freeProductType;	
	
	
	private Double unitPriceWithPromo;
	private Double unitPriceWithoutPromo;
	
	private Double recordPrice;
	private Double defContent;
	private Double recordQty;
	private Double recordPrdContent;
	private Double freePrdQty;
	private Double freePrdContent;
	private Double freePrdContentPercent;
	
	private Double bonusRedAmount;
	private Double bonusRedAmountPer;
	
	
	public Long getPriceRecordingId() {
		return priceRecordingId;
	}
	public void setPriceRecordingId(Long priceRecordingId) {
		this.priceRecordingId = priceRecordingId;
	}
	public Long getRecProductId() {
		return recProductId;
	}
	public void setRecProductId(Long recProductId) {
		this.recProductId = recProductId;
	}
	public Long getRecodingTypCd() {
		return recodingTypCd;
	}
	public void setRecodingTypCd(Long recodingTypCd) {
		this.recodingTypCd = recodingTypCd;
	}
	public Long getRecodeSourceCd() {
		return recodeSourceCd;
	}
	public void setRecodeSourceCd(Long recodeSourceCd) {
		this.recodeSourceCd = recodeSourceCd;
	}
	public Long getPriceBonusType() {
		return priceBonusType;
	}
	public void setPriceBonusType(Long priceBonusType) {
		this.priceBonusType = priceBonusType;
	}
	public Long getFreeProductType() {
		return freeProductType;
	}
	public void setFreeProductType(Long freeProductType) {
		this.freeProductType = freeProductType;
	}
	public Double getUnitPriceWithPromo() {
		return unitPriceWithPromo;
	}
	public void setUnitPriceWithPromo(Double unitPriceWithPromo) {
		this.unitPriceWithPromo = unitPriceWithPromo;
	}
	public Double getUnitPriceWithoutPromo() {
		return unitPriceWithoutPromo;
	}
	public void setUnitPriceWithoutPromo(Double unitPriceWithoutPromo) {
		this.unitPriceWithoutPromo = unitPriceWithoutPromo;
	}
	public Double getRecordPrice() {
		return recordPrice;
	}
	public void setRecordPrice(Double recordPrice) {
		this.recordPrice = recordPrice;
	}
	public Double getDefContent() {
		return defContent;
	}
	public void setDefContent(Double defContent) {
		this.defContent = defContent;
	}
	public Double getRecordQty() {
		return recordQty;
	}
	public void setRecordQty(Double recordQty) {
		this.recordQty = recordQty;
	}
	public Double getRecordPrdContent() {
		return recordPrdContent;
	}
	public void setRecordPrdContent(Double recordPrdContent) {
		this.recordPrdContent = recordPrdContent;
	}
	public Double getFreePrdQty() {
		return freePrdQty;
	}
	public void setFreePrdQty(Double freePrdQty) {
		this.freePrdQty = freePrdQty;
	}
	public Double getFreePrdContent() {
		return freePrdContent;
	}
	public void setFreePrdContent(Double freePrdContent) {
		this.freePrdContent = freePrdContent;
	}
	public Double getFreePrdContentPercent() {
		return freePrdContentPercent;
	}
	public void setFreePrdContentPercent(Double freePrdContentPercent) {
		this.freePrdContentPercent = freePrdContentPercent;
	}
	public Double getBonusRedAmount() {
		return bonusRedAmount;
	}
	public void setBonusRedAmount(Double bonusRedAmount) {
		this.bonusRedAmount = bonusRedAmount;
	}
	public Double getBonusRedAmountPer() {
		return bonusRedAmountPer;
	}
	public void setBonusRedAmountPer(Double bonusRedAmountPer) {
		this.bonusRedAmountPer = bonusRedAmountPer;
	}
	
	
	
}
