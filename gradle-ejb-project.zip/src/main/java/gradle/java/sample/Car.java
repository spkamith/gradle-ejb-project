package gradle.java.sample;
public class Car {
    public String brand = null;
    public int    doors = 0;
}